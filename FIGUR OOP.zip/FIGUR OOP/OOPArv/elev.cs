﻿using System;
namespace OOPArv
{
    public abstract class Figur
    {
        public double L { get; set; }
        public double W { get; set; }
        public double R { get; set; }
    }
}