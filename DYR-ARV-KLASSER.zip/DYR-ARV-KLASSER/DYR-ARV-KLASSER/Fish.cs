﻿using System;
namespace DYRARVKLASSER
{
    public class Fish:Kæledyr
    {
        public string Blob { get; set; }
        public Fish(string Race, string Alder, string Afstammer) : base(Race, Alder, Afstammer)
        {

        }
    }
}
